<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Atlantic Falcons</title>
    
    
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>

<!-- css -->
<link rel="stylesheet" href="<?php echo base_url('css/style.css');?>" type="text/css" /><style type="text/css">._css3m{display:none}</style>

<!--header javascript if needed-->

</head>

<body>


