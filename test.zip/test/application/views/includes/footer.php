<footer>
© 2013 Atlanta Falcons Football Club
</footer>

<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>




</body>

</html>