<h2>Testing structure</h2>
<h3>Testing structures</h3>
<a href="<?php echo base_url();?>index.php/welcome/test2sdf" >test link</a>